///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ===============
// Manage the viewing of 3D objects within the viewport.
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330 Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Declaration of global variables and constants.
namespace
{
	// Variables for window width and height.
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// Camera used for viewing and interacting with the scene.
	Camera* g_pCamera = nullptr;

	// Variables used for mouse movement processing.
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Time between the current frame and the previous frame.
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// False selects perspective projection.
	// True selects orthographic projection.
	bool bOrthographicProjection = false;
}

/***********************************************************
 * ViewManager()
 *
 * The constructor for the class.
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// Initialize the member variables.
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	g_pCamera = new Camera();

	// Default camera view parameters.
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80.0f;

	// Set a comfortable starting movement speed.
	g_pCamera->MovementSpeed = 5.0f;
}

/***********************************************************
 * ~ViewManager()
 *
 * The destructor for the class.
 ***********************************************************/
ViewManager::~ViewManager()
{
	// Free allocated memory.
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 * CreateDisplayWindow()
 *
 * This method creates the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// Try to create the displayed OpenGL window.
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}

	glfwMakeContextCurrent(window);

	// Capture the mouse cursor so it can control the camera.
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// Register the mouse position callback.
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// Register the mouse scroll callback.
	glfwSetScrollCallback(
		window,
		&ViewManager::Mouse_Scroll_Callback);

	// Enable blending to support transparent rendering.
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 * Mouse_Position_Callback()
 *
 * This method is automatically called whenever the mouse
 * moves within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	// Store the initial mouse location to prevent the camera
	// from suddenly jumping when mouse input begins.
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	// Determine how far the mouse moved.
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// Save the current position for the next callback.
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Update the camera horizontal and vertical orientation.
	if (g_pCamera != nullptr)
	{
		g_pCamera->ProcessMouseMovement(
			xOffset,
			yOffset);
	}
}

/***********************************************************
 * Mouse_Scroll_Callback()
 *
 * This method changes the camera movement speed whenever
 * the mouse wheel is scrolled.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	if (g_pCamera == nullptr)
	{
		return;
	}

	// Increase or decrease the camera movement speed.
	g_pCamera->MovementSpeed +=
		static_cast<float>(yOffset);

	// Keep the movement speed within a usable range.
	if (g_pCamera->MovementSpeed < 1.0f)
	{
		g_pCamera->MovementSpeed = 1.0f;
	}
	else if (g_pCamera->MovementSpeed > 20.0f)
	{
		g_pCamera->MovementSpeed = 20.0f;
	}
}

/***********************************************************
 * ProcessKeyboardEvents()
 *
 * This method processes keyboard input for camera movement
 * and projection selection.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	if (m_pWindow == nullptr || g_pCamera == nullptr)
	{
		return;
	}

	// Close the window when Escape is pressed.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	// Move forward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			gDeltaTime);
	}

	// Move backward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			gDeltaTime);
	}

	// Move left.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			gDeltaTime);
	}

	// Move right.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			gDeltaTime);
	}

	// Move upward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position +=
			g_pCamera->Up *
			g_pCamera->MovementSpeed *
			gDeltaTime;
	}

	// Move downward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position -=
			g_pCamera->Up *
			g_pCamera->MovementSpeed *
			gDeltaTime;
	}

	// Select perspective projection.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// Select orthographic projection.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}
}

/***********************************************************
 * PrepareSceneView()
 *
 * This method prepares the view and projection matrices
 * used to render the 3D scene.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;
	glm::vec3 activeViewPosition;

	// Calculate the time between frames.
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// Process keyboard input.
	ProcessKeyboardEvents();

	// Use the current camera position and orientation for
	// both perspective and orthographic projection modes.
	view = g_pCamera->GetViewMatrix();
	activeViewPosition = g_pCamera->Position;

	// Calculate the display aspect ratio.
	float aspectRatio =
		static_cast<float>(WINDOW_WIDTH) /
		static_cast<float>(WINDOW_HEIGHT);

	// Calculate the selected projection matrix.
	if (bOrthographicProjection)
	{
		const float orthoSize = 10.0f;

		projection = glm::ortho(
			-orthoSize * aspectRatio,
			orthoSize * aspectRatio,
			-orthoSize,
			orthoSize,
			-100.0f,
			100.0f);
	}
	else
	{
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			aspectRatio,
			0.1f,
			100.0f);
	}

	// Send the view information to the shader.
	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		m_pShaderManager->setVec3Value(
			"viewPosition",
			activeViewPosition);
	}
}
///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby, SNHU Instructor, Computer Science
// Created for CS 330 Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// Declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 * SceneManager()
 *
 * The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
	: m_pShaderManager(pShaderManager),
	m_basicMeshes(new ShapeMeshes()),
	m_loadedTextures(0)
{
}

/***********************************************************
 * ~SceneManager()
 *
 * The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;

	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 * CreateGLTexture()
 *
 * This method loads a texture from an image file and places
 * the resulting texture data into OpenGL texture memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(
	const char* filename,
	std::string tag)
{
	if (m_loadedTextures >= 16)
	{
		std::cout
			<< "Texture limit reached. Could not load: "
			<< filename
			<< std::endl;

		return false;
	}

	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// Flip images vertically when they are loaded.
	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	if (image)
	{
		std::cout
			<< "Successfully loaded image: "
			<< filename
			<< ", width: "
			<< width
			<< ", height: "
			<< height
			<< ", channels: "
			<< colorChannels
			<< std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Configure texture wrapping.
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_S,
			GL_REPEAT);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_T,
			GL_REPEAT);

		// Configure texture filtering.
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MIN_FILTER,
			GL_LINEAR_MIPMAP_LINEAR);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MAG_FILTER,
			GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGB8,
				width,
				height,
				0,
				GL_RGB,
				GL_UNSIGNED_BYTE,
				image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGBA8,
				width,
				height,
				0,
				GL_RGBA,
				GL_UNSIGNED_BYTE,
				image);
		}
		else
		{
			std::cout
				<< "Image format with "
				<< colorChannels
				<< " channels is not supported."
				<< std::endl;

			stbi_image_free(image);
			glBindTexture(GL_TEXTURE_2D, 0);
			glDeleteTextures(1, &textureID);

			return false;
		}

		// Generate lower resolution versions of the texture.
		glGenerateMipmap(GL_TEXTURE_2D);

		// Release the image data after it is sent to OpenGL.
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout
		<< "Could not load image: "
		<< filename
		<< std::endl;

	return false;
}

/***********************************************************
 * BindGLTextures()
 *
 * This method binds the loaded textures to their assigned
 * OpenGL texture slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);

		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[i].ID);
	}
}

/***********************************************************
 * DestroyGLTextures()
 *
 * This method releases all texture objects created for the
 * current scene.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(
			1,
			&m_textureIDs[i].ID);
	}

	m_loadedTextures = 0;
}

/***********************************************************
 * FindTextureID()
 *
 * This method finds the OpenGL texture identifier associated
 * with a texture tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) &&
		(bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureID;
}

/***********************************************************
 * FindTextureSlot()
 *
 * This method finds the texture slot associated with a
 * texture tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) &&
		(bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureSlot;
}

/***********************************************************
 * FindMaterial()
 *
 * This method finds the stored material associated with a
 * material tag.
 ***********************************************************/
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.empty())
	{
		return false;
	}

	std::size_t index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) &&
		(bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			material.ambientColor =
				m_objectMaterials[index].ambientColor;

			material.ambientStrength =
				m_objectMaterials[index].ambientStrength;

			material.diffuseColor =
				m_objectMaterials[index].diffuseColor;

			material.specularColor =
				m_objectMaterials[index].specularColor;

			material.shininess =
				m_objectMaterials[index].shininess;

			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

/***********************************************************
 * SetTransformations()
 *
 * This method applies scaling, rotation, and translation to
 * the next object that will be rendered.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);

	rotationX = glm::rotate(
		glm::radians(XrotationDegrees),
		glm::vec3(1.0f, 0.0f, 0.0f));

	rotationY = glm::rotate(
		glm::radians(YrotationDegrees),
		glm::vec3(0.0f, 1.0f, 0.0f));

	rotationZ = glm::rotate(
		glm::radians(ZrotationDegrees),
		glm::vec3(0.0f, 0.0f, 1.0f));

	translation = glm::translate(positionXYZ);

	modelView =
		translation *
		rotationX *
		rotationY *
		rotationZ *
		scale;

	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

/***********************************************************
 * SetShaderColor()
 *
 * This method sends an object color to the fragment shader.
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

/***********************************************************
 * SetShaderTexture()
 *
 * This method selects the texture used by the next object.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (m_pShaderManager != nullptr)
	{
		int textureSlot =
			FindTextureSlot(textureTag);

		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureSlot);
	}
}

/***********************************************************
 * SetTextureUVScale()
 *
 * This method controls texture tiling across an object.
 ***********************************************************/
void SceneManager::SetTextureUVScale(
	float u,
	float v)
{
	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(u, v));
	}
}

/***********************************************************
 * SetShaderMaterial()
 *
 * This method sends the selected material properties to the
 * fragment shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if ((m_pShaderManager != nullptr) &&
		(m_objectMaterials.empty() == false))
	{
		OBJECT_MATERIAL material;

		bool bFound =
			FindMaterial(
				materialTag,
				material);

		if (bFound)
		{
			m_pShaderManager->setVec3Value(
				"material.ambientColor",
				material.ambientColor);

			m_pShaderManager->setFloatValue(
				"material.ambientStrength",
				material.ambientStrength);

			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}

namespace
{
	/***********************************************************
	 * CreateSceneMaterials()
	 *
	 *  * This function defines the surface materials used by the
     * wooden desktop, textured screens, and plastic objects.
	 ***********************************************************/
	std::vector<SceneManager::OBJECT_MATERIAL>
		CreateSceneMaterials()
	{
		std::vector<SceneManager::OBJECT_MATERIAL>
			materials;

		// Wood material for the textured desktop plane.
		SceneManager::OBJECT_MATERIAL woodMaterial;

		woodMaterial.ambientColor =
			glm::vec3(0.30f, 0.22f, 0.14f);

		woodMaterial.ambientStrength = 0.45f;

		woodMaterial.diffuseColor =
			glm::vec3(0.90f, 0.82f, 0.72f);

		woodMaterial.specularColor =
			glm::vec3(0.45f, 0.36f, 0.26f);

		woodMaterial.shininess = 0.35f;
		woodMaterial.tag = "wood";

		materials.push_back(woodMaterial);

		// Plastic material for the monitor bodies and stands.
		SceneManager::OBJECT_MATERIAL plasticMaterial;

		plasticMaterial.ambientColor =
			glm::vec3(0.65f, 0.65f, 0.70f);

		plasticMaterial.ambientStrength = 0.70f;

		plasticMaterial.diffuseColor =
			glm::vec3(0.78f, 0.78f, 0.82f);

		plasticMaterial.specularColor =
			glm::vec3(0.90f, 0.90f, 0.95f);

		plasticMaterial.shininess = 0.65f;
		plasticMaterial.tag = "plastic";

		materials.push_back(plasticMaterial);

		// Screen material keeps the display texture visible.
		SceneManager::OBJECT_MATERIAL screenMaterial;

		screenMaterial.ambientColor =
			glm::vec3(0.50f, 0.50f, 0.50f);

		screenMaterial.ambientStrength = 0.70f;

		screenMaterial.diffuseColor =
			glm::vec3(0.90f, 0.90f, 0.90f);

		screenMaterial.specularColor =
			glm::vec3(0.30f, 0.30f, 0.35f);

		screenMaterial.shininess = 0.15f;
		screenMaterial.tag = "screen";

		materials.push_back(screenMaterial);

		return materials;
	}

/***********************************************************
 * SetupSceneLights()
 *
 * This function configures four point lights. The green
 * accent, warm key, and overhead lights illuminate the
 * desktop scene. A warm yellow light represents the glow
 * produced by the lamb mood lamp.
 ***********************************************************/
	void SetupSceneLights(
		ShaderManager* pShaderManager)
	{
		if (pShaderManager == nullptr)
		{
			return;
		}

		// Green accent light from the front left.
		pShaderManager->setVec3Value(
			"lightSources[0].position",
			glm::vec3(-6.0f, 10.0f, 8.0f));

		pShaderManager->setVec3Value(
			"lightSources[0].ambientColor",
			glm::vec3(0.03f, 0.16f, 0.8f));

		pShaderManager->setVec3Value(
			"lightSources[0].diffuseColor",
			glm::vec3(0.08f, 0.90f, 0.30f));

		pShaderManager->setVec3Value(
			"lightSources[0].specularColor",
			glm::vec3(0.12f, 0.95f, 0.18f));

		pShaderManager->setFloatValue(
			"lightSources[0].focalStrength",
			32.0f);

		pShaderManager->setFloatValue(
			"lightSources[0].specularIntensity",
			0.30f);

		// Primary warm white light from the front right.
		pShaderManager->setVec3Value(
			"lightSources[1].position",
			glm::vec3(6.0f, 8.0f, 6.0f));

		pShaderManager->setVec3Value(
			"lightSources[1].ambientColor",
			glm::vec3(0.16f, 0.14f, 0.11f));

		pShaderManager->setVec3Value(
			"lightSources[1].diffuseColor",
			glm::vec3(0.48f, 0.42f, 0.34f));

		pShaderManager->setVec3Value(
			"lightSources[1].specularColor",
			glm::vec3(0.60f, 0.52f, 0.42f));

		pShaderManager->setFloatValue(
			"lightSources[1].focalStrength",
			24.0f);

		pShaderManager->setFloatValue(
			"lightSources[1].specularIntensity",
			0.28f);

		// Warm white overhead light.
		pShaderManager->setVec3Value(
			"lightSources[2].position",
			glm::vec3(0.0f, 12.0f, 0.0f));

		pShaderManager->setVec3Value(
			"lightSources[2].ambientColor",
			glm::vec3(0.12f, 0.105f, 0.08f));

		pShaderManager->setVec3Value(
			"lightSources[2].diffuseColor",
			glm::vec3(0.34f, 0.29f, 0.23f));

		pShaderManager->setVec3Value(
			"lightSources[2].specularColor",
			glm::vec3(0.45f, 0.39f, 0.31f));

		pShaderManager->setFloatValue(
			"lightSources[2].focalStrength",
			48.0f);

		pShaderManager->setFloatValue(
			"lightSources[2].specularIntensity",
			0.22f);

		// Strong warm yellow point light from the lamb mood lamp.
		pShaderManager->setVec3Value(
			"lightSources[3].position",
			glm::vec3(0.0f, 2.10f, 0.40f));

		pShaderManager->setVec3Value(
			"lightSources[3].ambientColor",
			glm::vec3(0.28f, 0.20f, 0.06f));

		pShaderManager->setVec3Value(
			"lightSources[3].diffuseColor",
			glm::vec3(1.20f, 0.85f, 0.25f));

		pShaderManager->setVec3Value(
			"lightSources[3].specularColor",
			glm::vec3(1.30f, 1.00f, 0.35f));

		pShaderManager->setFloatValue(
			"lightSources[3].focalStrength",
			12.0f);

		pShaderManager->setFloatValue(
			"lightSources[3].specularIntensity",
			0.50f);

		// Enable Phong lighting for the scene.
		pShaderManager->setIntValue(
			g_UseLightingName,
			true);
	}
}

/***********************************************************
 * PrepareScene()
 *
 * This method loads the textures, creates the materials,
 * configures the lights, and loads the required meshes.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load the wooden desktop texture.
	CreateGLTexture(
		"../../Utilities/textures/Wood028_1K-JPG_Color.jpg",
		"desktop");

	// Load the plastic monitor texture.
	CreateGLTexture(
		"../../Utilities/textures/Plastic006_1K-JPG_Color.jpg",
		"monitorPlastic");

	// Load the image displayed on the left monitor screen.
	CreateGLTexture(
		"../../Utilities/textures/Screen_L.jpg",
		"leftScreen");

	// Load the image displayed on the right monitor screen.
	CreateGLTexture(
		"../../Utilities/textures/Screen_R.jpg",
		"rightScreen");

	// Load the dragon texture for the left desk mat.
	CreateGLTexture(
		"../../Utilities/textures/Dragon_mat.png",
		"dragonMat");

	// Load the cat texture for the right desk mat.
	CreateGLTexture(
		"../../Utilities/textures/Kitty_mat.png",
		"kittyMat");

	// Load the photographed keyboard texture.
	CreateGLTexture(
		"../../Utilities/textures/personal_Keyboard_Texture.png",
		"keyboard");

	BindGLTextures();

	// Create materials used by the Phong lighting shader.
	m_objectMaterials = CreateSceneMaterials();

	// Configure and enable all four light sources.
	SetupSceneLights(m_pShaderManager);

	// Load one copy of each required mesh.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 * RenderScene()
 *
 * This method renders the complete dual monitor desktop
 * scene using transformed and textured basic meshes.
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/
	// Draw the wooden desktop plane.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(20.0f, 1.0f, 10.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(0.0f, 1.10f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("desktop");
	SetTextureUVScale(4.0f, 4.0f);
	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();

/****************************************************************/
// Draw the left desk mat.
/****************************************************************/

	scaleXYZ =
		glm::vec3(8.5f, 0.08f, 5.5f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-4.3f, 1.18f, 2.1f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.08f,
		0.10f,
		0.11f,
		1.0f);

	SetShaderTexture("dragonMat");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	// Draw the right desk mat.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(8.5f, 0.08f, 5.5f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(4.3f, 1.18f, 2.1f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.08f,
		0.10f,
		0.11f,
		1.0f);

	SetShaderTexture("kittyMat");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

/****************************************************************/
// Draw the keyboard on the desk mats.
/****************************************************************/

	scaleXYZ =
		glm::vec3(5.5f, 0.22f, 1.8f);

	XrotationDegrees = 5.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(0.0f, 1.34f, 2.6f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("keyboard");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	// Draw the left monitor body.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(6.0f, 3.8f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 37.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-2.60f, 4.3f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
// Draw the left monitor screen.
/****************************************************************/

	scaleXYZ =
		glm::vec3(5.4f, 3.2f, 0.08f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 37.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-2.25f, 4.3f, 0.28f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("leftScreen");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("screen");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	// Draw the left monitor stand post.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.45f, 1.8f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-2.60f, 1.50f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	// Draw the left monitor stand base.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(3.0f, 0.30f, 1.8f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 37.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-2.60f, 1.35f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	// Draw the right monitor body.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(6.0f, 3.8f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -37.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(2.60f, 4.3f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

/****************************************************************/
// Draw the right monitor screen.
/****************************************************************/

	scaleXYZ =
		glm::vec3(5.4f, 3.2f, 0.08f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -37.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(2.25f, 4.3f, 0.28f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("rightScreen");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("screen");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	// Draw the right monitor stand post.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.45f, 1.8f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(2.60f, 1.50f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	// Draw the right monitor stand base.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(3.0f, 0.30f, 1.8f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -37.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(2.60f, 1.35f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

/****************************************************************/
// Draw the left cylindrical speaker.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.75f, 1.9f, 0.75f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-1.5f, 1.15f, -2.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.08f,
		0.08f,
		0.10f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();

/****************************************************************/
// Draw the right cylindrical speaker.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.75f, 1.9f, 0.75f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(1.5f, 1.15f, -2.5);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.08f,
		0.08f,
		0.10f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();

/****************************************************************/
// Draw the computer mouse on the right desk mat.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.65f, 0.28f, 1.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(4.0f, 1.45f, 2.9f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.10f,
		0.10f,
		0.12f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();

	/****************************************************************/
// Draw the base of the lamb mood lamp.
/****************************************************************/

	scaleXYZ =
		glm::vec3(2.25f, 0.21f, 1.05f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(0.0f, 1.24f, 0.20f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.12f,
		0.13f,
		0.14f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
// Draw the glowing wool section of the lamb mood lamp.
/****************************************************************/

// Center wool sphere.
	scaleXYZ =
		glm::vec3(0.60f, 0.60f, 0.39f);

	positionXYZ =
		glm::vec3(0.0f, 1.88f, 0.20f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.88f,
		0.58f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	// Upper wool sphere.
	scaleXYZ =
		glm::vec3(0.49f, 0.49f, 0.35f);

	positionXYZ =
		glm::vec3(0.0f, 2.37f, 0.18f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.90f,
		0.62f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	// Upper left wool sphere.
	scaleXYZ =
		glm::vec3(0.43f, 0.43f, 0.35f);

	positionXYZ =
		glm::vec3(-0.46f, 2.21f, 0.18f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.90f,
		0.62f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	// Upper right wool sphere.
	scaleXYZ =
		glm::vec3(0.43f, 0.43f, 0.35f);

	positionXYZ =
		glm::vec3(0.46f, 2.21f, 0.18f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.90f,
		0.62f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	// Lower left wool sphere.
	scaleXYZ =
		glm::vec3(0.48f, 0.48f, 0.36f);

	positionXYZ =
		glm::vec3(-0.48f, 1.74f, 0.18f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.88f,
		0.58f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	// Lower right wool sphere.
	scaleXYZ =
		glm::vec3(0.48f, 0.48f, 0.36f);

	positionXYZ =
		glm::vec3(0.48f, 1.74f, 0.18f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.88f,
		0.58f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	// Far right wool sphere.
	scaleXYZ =
		glm::vec3(0.39f, 0.43f, 0.34f);

	positionXYZ =
		glm::vec3(0.81f, 1.98f, 0.15f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.88f,
		0.58f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the dark head of the lamb.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.39f, 0.50f, 0.34f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -18.0f;

	positionXYZ =
		glm::vec3(-0.81f, 1.70f, 0.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.05f,
		0.10f,
		0.22f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
// Draw a small wool tuft above the lamb head.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.21f, 0.17f, 0.18f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-0.78f, 2.11f, 0.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.90f,
		0.62f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();

	/****************************************************************/
// Draw the left horn of the lamb.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.15f, 0.32f, 0.15f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 65.0f;

	positionXYZ =
		glm::vec3(-1.06f, 1.98f, 0.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.10f,
		0.10f,
		0.12f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawConeMesh();

	/****************************************************************/
// Draw the right horn of the lamb.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.15f, 0.32f, 0.15f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -65.0f;

	positionXYZ =
		glm::vec3(-0.53f, 1.98f, 0.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.10f,
		0.10f,
		0.12f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawConeMesh();

	/****************************************************************/
// Draw the glowing orange tail on the lower right side.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.29f, 0.29f, 0.27f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(0.88f, 1.51f, 0.42f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		1.0f,
		0.48f,
		0.05f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();

	/****************************************************************/
// Draw the blue body of the frog fan.
/****************************************************************/

	scaleXYZ =
		glm::vec3(1.35f, 1.45f, 0.55f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-6.0f, 2.25f, 2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.05f,
		0.35f,
		0.80f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the circular fan housing.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.80f, 0.10f, 0.80f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-6.0f, 2.25f, 2.45f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.08f,
		0.08f,
		0.10f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	// Draw the left frog eye.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.38f, 0.38f, 0.30f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-6.65f, 3.48f, 2.45f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.92f,
		0.92f,
		0.95f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the right frog eye.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.38f, 0.38f, 0.30f);

	positionXYZ =
		glm::vec3(-5.35f, 3.48f, 2.45f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.92f,
		0.92f,
		0.95f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the left pupil.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.20f, 0.20f, 0.16f);

	positionXYZ =
		glm::vec3(-6.65f, 3.48f, 2.72f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.02f,
		0.02f,
		0.03f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the right pupil.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.20f, 0.20f, 0.16f);

	positionXYZ =
		glm::vec3(-5.35f, 3.48f, 2.72f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(
		0.02f,
		0.02f,
		0.03f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the left frog foot.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.50f, 0.30f, 0.65f);

	positionXYZ =
		glm::vec3(-6.65f, 1.35f, 2.20f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		-12.0f,
		positionXYZ);

	SetShaderColor(
		0.05f,
		0.35f,
		0.80f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	// Draw the right frog foot.
	/****************************************************************/

	scaleXYZ =
		glm::vec3(0.50f, 0.30f, 0.65f);

	positionXYZ =
		glm::vec3(-5.35f, 1.35f, 2.20f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		12.0f,
		positionXYZ);

	SetShaderColor(
		0.05f,
		0.35f,
		0.80f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


/****************************************************************/
// Draw the left cylindrical frog arm.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.22f, 1.00f, 0.22f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -35.0f;

	positionXYZ =
		glm::vec3(-7.40f, 2.05f, 2.05f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.05f,
		0.35f,
		0.80f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();

/****************************************************************/
// Draw the left white frog glove.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.42f, 0.45f, 0.38f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-7.55f, 1.65f, 2.05f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.92f,
		0.92f,
		0.95f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();


/****************************************************************/
// Draw the right cylindrical frog arm.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.22f, 1.00f, 0.22f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 35.0f;

	positionXYZ =
		glm::vec3(-4.60f, 2.05f, 2.05f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.05f,
		0.35f,
		0.80f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawCylinderMesh();

/****************************************************************/
// Draw the right white frog glove.
/****************************************************************/

	scaleXYZ =
		glm::vec3(0.42f, 0.45f, 0.38f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(-4.45f, 1.65f, 2.05f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.92f,
		0.92f,
		0.95f,
		1.0f);

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawSphereMesh();
}
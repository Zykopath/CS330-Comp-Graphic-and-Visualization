///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// =============
// Manage the viewing of 3D objects within the viewport.
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h"

class ViewManager
{
public:
	// Constructor.
	ViewManager(
		ShaderManager* pShaderManager);

	// Destructor.
	~ViewManager();

	// Mouse-position callback for changing the camera orientation.
	static void Mouse_Position_Callback(
		GLFWwindow* window,
		double xMousePos,
		double yMousePos);

	// Mouse-scroll callback for adjusting camera movement speed.
	static void Mouse_Scroll_Callback(
		GLFWwindow* window,
		double xOffset,
		double yOffset);

	// Create the initial OpenGL display window.
	GLFWwindow* CreateDisplayWindow(
		const char* windowTitle);

	// Prepare the conversion from the 3D world to the 2D display.
	void PrepareSceneView();

private:
	// Pointer to the shader manager object.
	ShaderManager* m_pShaderManager;

	// Active OpenGL display window.
	GLFWwindow* m_pWindow;

	// Process keyboard events for interaction with the 3D scene.
	void ProcessKeyboardEvents();
};